// import React from 'react'

// export const Profile = () => {
//   return (
//     <div>P
//         <h1>Profile </h1>
//         </div>
//   )
// }

