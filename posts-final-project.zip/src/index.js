import React from 'react';
import ReactDOM from 'react-dom';
import { App } from './App.js';

// document.body.style.backgroundImage = url('./assets/background.png')
ReactDOM.render(<App />, document.getElementById('root'));