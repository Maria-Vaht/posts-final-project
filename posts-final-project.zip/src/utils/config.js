export const config = {
    url: 'https://api.react-learning.ru',
    token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjU4NGE4ODBjZGQ3ZDNmZDUyZjgyY2QiLCJpYXQiOjE2NDk5NTQwNDksImV4cCI6MTY4MTQ5MDA0OX0.yysOlypfrMpNixCbiixYQAnILvFFRLaH2muDFnf6ze4'
}