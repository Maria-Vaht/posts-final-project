// import React from 'react'

// export const SignUp = () => {
//   return (
//     <div>
//         <h3>SignUp </h3>
//         </div>
//   )
// }
