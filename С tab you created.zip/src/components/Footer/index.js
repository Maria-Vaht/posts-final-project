import React from "react";
import './index.css'

const Footer = () => {
  return (
   <footer>
      <p>&copy;2022</p>
   </footer>
  )
}

export default Footer